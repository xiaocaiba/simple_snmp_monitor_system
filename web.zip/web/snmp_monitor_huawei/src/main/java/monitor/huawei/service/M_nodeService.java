package monitor.huawei.service;

import monitor.huawei.entity.Monitor_node;
import monitor.huawei.entity.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class M_nodeService {
    @Autowired
    JdbcTemplate jdbcTemplate;

    final Logger log = LoggerFactory.getLogger(getClass());     //使用logger打印日志
    RowMapper<Monitor_node> NodeRowMapper = new BeanPropertyRowMapper<>(Monitor_node.class); // RowMapper实现表到类的映射
    
    public List<Monitor_node> get_monitor_nodes_by_device(String device) {
        return jdbcTemplate.query("select * from monitor_data where sysName=? order by port",NodeRowMapper,new Object[]{device});
    }

    public List<Monitor_node> get_latest() {
        String sql = "SELECT * FROM (SELECT * FROM monitor_data ORDER BY id DESC LIMIT 18) subquery ORDER BY id ASC;";
        return jdbcTemplate.query(sql,NodeRowMapper);
    }
}
