package monitor.huawei.web;


import monitor.huawei.entity.Monitor_node;
import monitor.huawei.service.M_nodeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class M_nodeController {

    final Logger logger = LoggerFactory.getLogger(getClass());
    
    @Autowired
    M_nodeService m_nodeService;
    
    @PostMapping("/request_by_device")
    public  ResponseEntity<List<Monitor_node>> get_data_by_deivce(@RequestParam("d_id") String device){
        List<Monitor_node> nodes = m_nodeService.get_monitor_nodes_by_device(device);
        return new ResponseEntity<>(nodes, HttpStatus.OK);
    }
    
    @PostMapping("/request_lastest")
    public ResponseEntity<List<Monitor_node>> get_latest_data(){
        List<Monitor_node> lastest_data = m_nodeService.get_latest();
        return new ResponseEntity<>(lastest_data, HttpStatus.OK);
    }
}
