package monitor.huawei.entity;

import java.sql.Timestamp;

public class Monitor_node {
    
    private int id;
    private String ip;
    private  int port;

    private String sysName;

    private long ifInOctets;
    private long ifInUcastpkts;
    private long ifInNUcastpkts;
    private long ifInErrors;

    private long ifOutOctets;
    private long ifOutUcastpkts;
    private long ifOutNUcastpkts;
    private long ifOutErrors;

    public Timestamp getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }

    private Timestamp timestamp;

    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public String getSysName() {
        return sysName;
    }

    public void setSysName(String sysName) {
        this.sysName = sysName;
    }

    public long getIfInOctets() {
        return ifInOctets;
    }

    public void setIfInOctets(long ifInOctets) {
        this.ifInOctets = ifInOctets;
    }

    public long getIfInUcastpkts() {
        return ifInUcastpkts;
    }

    public void setIfInUcastpkts(long ifInUcastpkts) {
        this.ifInUcastpkts = ifInUcastpkts;
    }

    public long getIfInNUcastpkts() {
        return ifInNUcastpkts;
    }

    public void setIfInNUcastpkts(long ifInNUcastpkts) {
        this.ifInNUcastpkts = ifInNUcastpkts;
    }

    public long getIfInErrors() {
        return ifInErrors;
    }

    public void setIfInErrors(long ifInErrors) {
        this.ifInErrors = ifInErrors;
    }

    public long getIfOutOctets() {
        return ifOutOctets;
    }

    public void setIfOutOctets(long ifOutOctets) {
        this.ifOutOctets = ifOutOctets;
    }

    public long getIfOutUcastpkts() {
        return ifOutUcastpkts;
    }

    public void setIfOutUcastpkts(long ifOutUcastpkts) {
        this.ifOutUcastpkts = ifOutUcastpkts;
    }

    public long getIfOutNUcastpkts() {
        return ifOutNUcastpkts;
    }

    public void setIfOutNUcastpkts(long ifOutNUcastpkts) {
        this.ifOutNUcastpkts = ifOutNUcastpkts;
    }

    public long getIfOutErrors() {
        return ifOutErrors;
    }

    public void setIfOutErrors(long ifOutErrors) {
        this.ifOutErrors = ifOutErrors;
    }

}
