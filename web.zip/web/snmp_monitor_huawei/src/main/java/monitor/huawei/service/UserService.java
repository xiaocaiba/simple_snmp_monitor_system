package monitor.huawei.service;

import monitor.huawei.entity.User;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Component;

import java.sql.Statement;

@Component
public class UserService {
    @Autowired
    JdbcTemplate jdbcTemplate;

    final Logger log = LoggerFactory.getLogger(getClass());     //使用logger打印日志
    RowMapper<User> userRowMapper = new BeanPropertyRowMapper<>(User.class); // RowMapper实现表到类的映射

    public User getUserById(String id) {
        return jdbcTemplate.queryForObject("select * from users where id=?",userRowMapper,new Object[]{id});
    }
    public User getUserByEmail(String email) {
        return jdbcTemplate.queryForObject("select * from users where email=?",userRowMapper,new Object[]{email});
    }
    public User signin(String email,String password)
    {

        log.info("try login in by{}..."+email);
        User user=getUserByEmail(email);
        if(user.getPassword().equals(password))
        {
            return user;
        }
        throw new RuntimeException("login falied");
    }
    public User register(String eamil,String password,String name)
    {
        log.info("try registe by {}..."+eamil);
        User user=new User();
        user.setEmail(eamil);
        user.setPassword(password);
        user.setName(name);
        user.setCreatedAt(System.currentTimeMillis());
        KeyHolder holder=new GeneratedKeyHolder();

        if(1!=jdbcTemplate.update((conn)->{
            var ps=conn.prepareStatement("insert into users (email,password,name,createdAt) values (?,?,?,?)", Statement.RETURN_GENERATED_KEYS);
            ps.setObject(1,user.getEmail());
            ps.setObject(2,user.getPassword());
            ps.setObject(3,user.getName());
            ps.setObject(4,user.getCreatedAt());
            return ps;
        },holder)){
            throw new RuntimeException("registe falied");
        };
        user.setId(holder.getKey().longValue());
        return user;
    }
    public void update(User user)
    {
        if(1!=jdbcTemplate.update("update user set name=? where email=?",user.getName(),user.getEmail())){
            throw new RuntimeException("update falied");
        }
    }
}