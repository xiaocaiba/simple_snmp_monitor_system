var nodes;
var network;

document.addEventListener("DOMContentLoaded", function () {

    nodes = new vis.DataSet([
        { id: 1, label: 'R1', group: 'router', color: 'green' },
        { id: 2, label: 'C1', group: 'switch', color: 'green' },
        { id: 3, label: 'C2', group: 'switch', color: 'green' },
        { id: 4, label: 'D1', group: 'switch', color: 'green' },
        { id: 5, label: 'D2', group: 'switch', color: 'green' },
        { id: 6, label: 'PC', group: 'pc', color: 'grey' },
        { id: 7, label: 'PC', group: 'pc', color: 'grey' },
        { id: 8, label: 'PC', group: 'pc', color: 'grey' },
        { id: 9, label: 'PC', group: 'pc', color: 'grey' },
        { id: 10, label: 'PC', group: 'pc', color: 'grey' },
        { id: 11, label: 'PC', group: 'pc', color: 'grey' }
    ]);

    var edges = new vis.DataSet([
        { from: 1, to: 2, label: '0/0/1 - 0/0/1' },
        { from: 1, to: 3, label: '0/0/2 - 0/0/1' },
        { from: 2, to: 3, label: '0/0/2 - 0/0/2' },
        { from: 2, to: 3, label: '0/0/3 - 0/0/3' },
        { from: 2, to: 4, label: '0/0/4 - 0/0/3' },
        { from: 3, to: 5, label: '0/0/4 - 0/0/3' },
        { from: 1, to: 6, label: '0/0/0' },
        { from: 4, to: 7, label: '0/0/1' },
        { from: 4, to: 8, label: '0/0/2' },
        { from: 5, to: 9, label: '0/0/1' },
        { from: 5, to: 10, label: '0/0/2' },
        { from: 3, to: 11, label: '0/0/5' }
    ]);

    var container = document.getElementById('network');

    var data = {
        nodes: nodes,
        edges: edges
    };

    var options = {
        groups: {
            router: {
                shape: 'triangle',
                size: 18
            },
            switch: {
                shape: 'box',
                size: 18
            },
            pc: {
                shape: 'square',
                size: 18
            }
        },
        nodes: {
            scaling: {
                min: 16,
                max: 32
            }
        },
        edges: {
            color: 'gray',
            smooth: false
        },
        physics: {
            barnesHut: { gravitationalConstant: -30000 },
            stabilization: { iterations: 2500 },
        }
    };

    network = new vis.Network(container, data, options);

});

function request_by_device(device) {
    $.ajax({
        url: "/request_by_device",
        data: { d_id: device },
        type: "POST",
        dataType: "json",
        success: function (nodes) {
            alert("请求成功！");

            console.log(nodes);

            let thead = '<thead thead >' + '<tr>' +
                '<th>系统名称</th>' +
                '<th>端口号</th>' +
                '<th>接收到的字节数</th>' +
                '<th>接收到的单播数据包数</th>' +
                '<th>接收到的非单播数据包数</th>' +
                '<th>接收错误的数目</th>' +
                '<th>发送的字节数</th>' +
                '<th>发送的单播数据包数</th>' +
                '<th>发送的非单播数据包数</th>' +
                '<th>发送错误的数目</th>' +
                '<th>查询时间</th>' +
                '</tr >' +
                '</thead >' +
                '<tbody class="data_table_body"></tbody>';

            $('#' + device + ' .table').empty();
            $('#' + device + ' .table').append(thead);
            // let table_body = '#' + device + 'data_table_body';

            $('#' + device + ' .data_table_body').empty();

            nodes.forEach(function (node) {
                let row = '<tr>' +
                    '<td>' + node.sysName + '</td>' +
                    '<td>' + node.port + '</td>' +
                    '<td>' + node.ifInOctets + '</td>' +
                    '<td>' + node.ifInUcastpkts + '</td>' +
                    '<td>' + node.ifInNUcastpkts + '</td>' +
                    '<td>' + node.ifInErrors + '</td>' +
                    '<td>' + node.ifOutOctets + '</td>' +
                    '<td>' + node.ifOutUcastpkts + '</td>' +
                    '<td>' + node.ifOutNUcastpkts + '</td>' +
                    '<td>' + node.ifOutErrors + '</td>' +
                    '<td>' + node.timestamp + '</td>' +
                    '</tr>';
                $('#' + device + ' .data_table_body').append(row);
            });
        },
        error: function (xhr, status, error) {
            console.error("AJAX请求失败: " + status + ", " + error);
        }

    })
}

function update_by_lastest(device) {
    $.ajax({
        url: "/request_lastest",
        data: {},
        type: "POST",
        dataType: "json",
        success: function (lastest_data) {
            alert("请求成功！");
            let thead = '<thead thead >' + '<tr>' +
                '<th>系统名称</th>' +
                '<th>端口号</th>' +
                '<th>接收到的字节数</th>' +
                '<th>接收到的单播数据包数</th>' +
                '<th>接收到的非单播数据包数</th>' +
                '<th>接收错误的数目</th>' +
                '<th>发送的字节数</th>' +
                '<th>发送的单播数据包数</th>' +
                '<th>发送的非单播数据包数</th>' +
                '<th>发送错误的数目</th>' +
                '<th>查询时间</th>' +
                '</tr >' +
                '</thead >' +
                '<tbody class="data_table_body"></tbody>';

            $('#' + device + ' .table').empty();
            $('#' + device + ' .table').append(thead);


            $('#' + device + ' .data_table_body').empty();

            var packetLoss = [0, 0, 0, 0, 0];

            lastest_data.forEach(function (node) {
                let row = '<tr>' +
                    '<td>' + node.sysName + '</td>' +
                    '<td>' + node.port + '</td>' +
                    '<td>' + node.ifInOctets + '</td>' +
                    '<td>' + node.ifInUcastpkts + '</td>' +
                    '<td>' + node.ifInNUcastpkts + '</td>' +
                    '<td>' + node.ifInErrors + '</td>' +
                    '<td>' + node.ifOutOctets + '</td>' +
                    '<td>' + node.ifOutUcastpkts + '</td>' +
                    '<td>' + node.ifOutNUcastpkts + '</td>' +
                    '<td>' + node.ifOutErrors + '</td>' +
                    '<td>' + node.timestamp + '</td>' +
                    '</tr>';
                $('#' + device + ' .data_table_body').append(row);


                // 计算丢失报文数量
                count_loss(node, packetLoss);

            });

            for (let i = 0; i < 5; i++) {
                let color;
                if (packetLoss[i] === 0) {
                    color = 'green';
                } else if (packetLoss[i] === 1) {
                    color = 'pink';
                } else if (packetLoss[i] === 2) {
                    color = 'lightcoral';
                } else if (packetLoss[i] >= 3) {
                    color = 'red';
                }
                nodes.update({ id: i + 1, color: { background: color } });
            }

        }

    })
}

function count_loss(node, packetLoss) {
    if (node.sysName == 'R1') {
        packetLoss[0] += node.ifInErrors + node.ifOutErrors;
    }
    else if (node.sysName == 'C1') {
        packetLoss[1] += node.ifInErrors + node.ifOutErrors;
    }
    else if (node.sysName == 'C2') {
        packetLoss[2] += node.ifInErrors + node.ifOutErrors;
    }
    else if (node.sysName == 'D1') {
        packetLoss[3] += node.ifInErrors + node.ifOutErrors;
    }
    else if (node.sysName == 'D2') {
        packetLoss[4] += node.ifInErrors + node.ifOutErrors;
    }

}

